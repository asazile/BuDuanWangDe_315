module.exports = {
    /**
     * This is Log use CONST
     */
    log: {
        modelsError: "log/models_error.txt",
        routersError: 'log/routes_error.txt'
    }
};